#include <iostream>

using namespace std;

const int MAX_ITEMS = 10;

void listItems(int nList[]){
	for (int i = 0; i < MAX_ITEMS; i++)
		cout << nList[i] << " - ";
	
	cout << "\n";
	
	return;
}

bool changeItems(int nList[], int nCurrItem, int nNextItem)
{	
	int tempItem = 0;
	
	tempItem = nList[nCurrItem];
	nList[nCurrItem] = nList[nNextItem];
	nList[nNextItem] = tempItem;
	
	return true;
}


int main(int argc, char** argv) {
	
	int *list = new int[MAX_ITEMS];
	
	// Fill list
	for (int i = 0; i < MAX_ITEMS; i++)
		list[i] = MAX_ITEMS - i;

	// Show list
	listItems(list);
	
	// Bubble sorting
	bool changedItem = false;
	
	do
	{
		changedItem = false;		
		for (int i = 0; i <= MAX_ITEMS; i++){
			if (list[i] > list[i+1]) 
				changedItem = changeItems(list, i, i+1);
		}
	} while (changedItem);
	
	// Show list result
	listItems(list);
	
	delete[] list;
	
	return 0;
}

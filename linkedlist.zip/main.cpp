#include <iostream>

using namespace std;

typedef struct contactStruct {
	int nId;
	string sName;
	contactStruct *next;
}contact;

contact *phoneBook = NULL;

void addContact(int id, string name){
	contact *newct = new contact;

	newct->nId = id;
	newct->sName = name;
	newct->next = phoneBook;

	phoneBook = newct;
				
	return;
}

void listContacts(){
	contact *ct = phoneBook;
	while (ct != NULL) {
		cout << "\n=\n" << ct->nId << "-" << ct->sName;
		ct = ct->next;
	} 

	return;
}

void delContact(int id){
	contact *ct = phoneBook;
	
	if (ct != NULL){
		if (ct->nId == id)
			phoneBook = ct->next;
		else
		{
			contact *prevct = ct;
			
			while (ct != NULL){
				if (ct->nId == id){
					prevct->next = ct->next;
					return;
				}
				prevct = ct;
				ct = ct->next;
			}
		}
	}
			
	return;
}

int main(int argc, char** argv) {
	
	addContact(1, "Thiago");
	addContact(2, "Simone");
	addContact(3, "Gabriel");
	addContact(4, "asd");
	
	listContacts();		
	
	delContact(3);
	
	listContacts();

	if (phoneBook != NULL)
		delete phoneBook;
		
	return 0;
}

#include <bits/stdc++.h>

using namespace std;

// Complete the gameOfStones function below.
string gameOfStones(int n) {
	int player = 2;
		
	while (n > 1){
		if (player == 2) player = 1; else player = 2;
						
		float tmp = 0;
		int sub = 0;
		
		if (n >= 5){ // test 5 sub
			if (n == 5) 
				n = n - 5;
			else {
				sub = 5;
				tmp = n%5;
				
				if (n%3 > tmp){
					tmp = n%3;
					sub = 3;
				}
				
				if (n%2 > tmp){
					 tmp = n%2;
					 sub = 2;
				}
				n = n - sub;
			}
		}
		else if (n >= 3){ // test 3 sub
			if (n == 3)
				n = n - 3;
			else {
				sub = 3;
				tmp = n%3;
				
				if (n%2 > tmp){
					tmp = n%2;
					sub = 2;
				}
				
				n = n - sub;
			}
		} // 2 sub
		else if (n >= 2){
			n = n - 2;
		}		
	}

	if (player == 1)
		return "First";
	else
		return "Second";

}

int main()
{
    ofstream fout(getenv("OUTPUT_PATH"));

	int t;
    cin >> t;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    for (int t_itr = 0; t_itr < t; t_itr++){
		int n;
        cin >> n;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

		cout << n << "\n";
        string result = gameOfStones(n);

		cout << result << "\n";
        fout << result << "\n";
    }	
	
    fout.close();

    return 0;
}


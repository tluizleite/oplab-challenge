import tweepy
import sys
import os
from dotenv import load_dotenv
import csv
import re

# Load credentials from .env file
load_dotenv()

if (len(sys.argv) == 1):
    print("This script requires word or phrase ("") as a parameter to search.")
    sys.exit(-1)

search_text = sys.argv[1]

# 1. Authenticate
auth = tweepy.OAuthHandler(os.getenv('CONSUMER_KEY'), os.getenv('CONSUMER_SECRET'))
auth.set_access_token(os.getenv('ACCESS_TOKEN'), os.getenv('ACCESS_TOKEN_SECRET'))
api = tweepy.API(auth)

if (not api):
    print("Authentication failed!")
    print("Please verify if you have a .env file with your CONSUMER and ACCESS_TOKEN credentials defined correctly.")
    sys.exit(-1)

# 2. Get data
print("Searching 10 more recent tweets with " + search_text + "...")
data = api.search(search_text, result_type="recent", count=10)

# 3. Save data
with open('search_result.csv', mode='w', encoding='utf-8', newline='') as csv_file:
    fieldnames = ['created_at', 'id', 'text']
    writer = csv.DictWriter(csv_file, fieldnames, delimiter="|")
    writer.writeheader()

    for tweetObject in data:
        writer.writerow({'text': tweetObject.text, 'created_at': tweetObject.created_at, 'id': tweetObject.id})

print('Done. Please verify the CSV file.')